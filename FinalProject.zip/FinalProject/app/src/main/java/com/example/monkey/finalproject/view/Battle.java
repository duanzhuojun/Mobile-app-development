package com.example.monkey.finalproject.view;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.monkey.finalproject.R;

public class Battle extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_battle);
    }
}
