package com.example.monkey.finalproject.audio;

/**
 * Created by Monkey on 4/11/17.
 */

public class BaseAudioOb {
    private String URL;

    public String getURL() {
        return URL;
    }

    public void setURL(String URL) {
        this.URL = URL;
    }
}
